#ifndef MAPA_H
#define MAPA_H

typedef struct Mapa{
    int maxv;
    int maxl;
    int posicao[100][100];
} MAP;

#endif /* MAPA_H */


#ifndef PERSONAGEM_H
#define PERSONAGEM_H


typedef struct Personagem{
    int x;
    int y;
    char dir;
    void * Tipo;
}PERSONAGEM;

#endif /* PERSONAGEM_H */

